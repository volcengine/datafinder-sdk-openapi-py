from setuptools import setup

setup(
    name='rangersdk',
    version='1.2.0',
    packages=['rangersdk', 'rangersdk.dslclient', 'rangersdk.dslcontent'],
    url='',
    license='bytedance',
    author='DataRangers',
    author_email='DataRangers@mail.bytedance.com',
    description='',
    install_requires=['requests']
)
